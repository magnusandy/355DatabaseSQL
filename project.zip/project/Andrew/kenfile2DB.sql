\COPY ns_t_clients_temp FROM ns_t_clients.txt
\COPY ns_t_items_temp FROM ns_t_items.txt
\COPY ns_t_exhibitions_temp FROM ns_t_exhibitions.txt
\COPY ns_t_item_creators_temp FROM ns_t_item_creators.txt

\COPY ns_t_locations_temp FROM ns_t_locations.txt
\COPY ns_t_exhibition_items_temp FROM ns_t_exhibition_items.txt
\COPY ns_t_exhibition_locations_temp FROM ns_t_exhibition_locations.txt
\COPY ns_t_location_doors_temp FROM ns_t_location_doors.txt
\COPY ns_t_materials_temp FROM ns_t_materials.txt
\COPY ns_t_materials_subcomponents_temp FROM ns_t_materials_subcomponents.txt
\COPY ns_t_external_locations_temp FROM ns_t_external_locations.txt
\COPY ns_t_internal_locations_temp FROM ns_t_internal_locations.txt
\COPY ns_t_item_locations_temp FROM ns_t_item_locations.txt
\COPY ns_t_item_materials_temp FROM ns_t_item_materials.txt
\COPY ns_t_item_transactions_temp FROM ns_t_item_transactions.txt
